from django.apps import AppConfig


class GcsemathsConfig(AppConfig):
    name = 'gcsemaths'
