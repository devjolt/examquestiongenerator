from django.apps import AppConfig


class PhysicsConfig(AppConfig):
    name = 'physics'
